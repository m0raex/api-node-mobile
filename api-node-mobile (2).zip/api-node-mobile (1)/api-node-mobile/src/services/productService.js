const bcrypt = require('bcrypt');
const produtoRepository = require('../repositories/produtoRepository');
const { v4: UUIDV4 } = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'SUACHAVESECRETA';

class ProdutoService{
    async register(nome,descricao, preco, categoria){
        const getproduto = await this.getByName(nome);
        console.log(getproduto);
        if(getproduto){
            throw new Error('Produto já cadastrado');
        }
        if (nome.length < 10 || nome.length > 60) {
            throw new Error('Nome do produto tem que ter entre 10 e 60 caracteres');
        }
        if (descricao.length < 10 || descricao.length > 500) {
            throw new Error('Descrição do produto deve ter entre 10 e 500 caracteres');
        }
        if (categoria.length < 10 || categoria.length > 30) {
            throw new Error('Categoria do produto tem que ter entre 10 e 30 caracteres');
        }
        


        const produto = await produtoRepository.createProduto({id: UUIDV4(), nome, descricao, preco, categoria});
        return produto;
    }

    async getByName(nome){
        return await produtoRepository.findByName(nome);
    }

 
    async getproduto(){
        return await produtoRepository.findAll();
    }
}

module.exports = new ProdutoService();